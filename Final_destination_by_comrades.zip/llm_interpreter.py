import os
from typing import List, Optional
from openai import OpenAI
from models import DirectiveBatchResponse

# Hardcode your fallback key here if environment variable is not set
HARDCODED_API_KEY = "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"

SYSTEM_PROMPT = """You are a domain-expert AI energy grid interpreter.
Analyze natural language operator notes and map EACH note to a structured directive constraint.

Allowed Directive Types:
- solar_reduction: Reductions in solar generation forecast (factor = usable fraction remaining, e.g., 80% reduction -> factor=0.2, 25% usable -> factor=0.25).
- minimum_battery_reserve: Raises battery minimum energy reserve (minimum_energy_kwh).
- no_charge_window: Battery charging disabled in window.
- no_discharge_window: Battery discharging disabled in window.
- max_grid_window: Grid import power capped at max_grid_kwh.
- no_op: Irrelevant/distractor notes that do not affect today's 24-hour schedule.

Rules:
1. Return EXACTLY one interpretation entry per note, maintaining exact note_index order (0-indexed).
2. For no_op: applies MUST be false and structured_adjustment MUST be null.
3. For non-no_op: applies MUST be true.
4. Time windows are whole-hour, start-inclusive, end-exclusive.
5. Hours must be unique integers 0-23 in ascending order.
6. Convert relative battery percentages using provided battery capacity.
"""


def interpret_operator_notes(
    operator_notes: List[str], 
    battery_capacity_kwh: float, 
    api_key: Optional[str] = None
) -> List[dict]:
    # Priority: 1. Passed argument -> 2. Environment Variable -> 3. Hardcoded Fallback Key
    api_key = api_key or os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY") or HARDCODED_API_KEY
    
    if not operator_notes or not api_key or api_key == "YOUR_OPENAI_API_KEY_HERE":
        return [
            {
                "note_index": i,
                "applies": False,
                "directive_type": "no_op",
                "structured_adjustment": None,
                "explanation": "No valid API key provided or empty notes."
            }
            for i in range(len(operator_notes))
        ]

    client = OpenAI(api_key=api_key)
    
    prompt_user = f"Battery Capacity: {battery_capacity_kwh} kWh\n\nOperator Notes:\n"
    for idx, note in enumerate(operator_notes):
        safe_note = str(note).replace("\n", " ").strip()
        prompt_user += f"[{idx}] \"{safe_note}\"\n"

    try:
        response = client.beta.chat.completions.parse(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt_user}
            ],
            response_format=DirectiveBatchResponse,
            temperature=0.0
        )
        parsed_data = response.choices[0].message.parsed
        return [interp.model_dump() for interp in parsed_data.interpretations]
    except Exception as e:
        return [
            {
                "note_index": i,
                "applies": False,
                "directive_type": "no_op",
                "structured_adjustment": None,
                "explanation": f"LLM parsing error: {str(e)}"
            }
            for i in range(len(operator_notes))
        ]