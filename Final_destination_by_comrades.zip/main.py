from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from models import OptimizeRequest, OptimizeResponse
from llm_interpreter import interpret_operator_notes
from guardrails import validate_all_directives
from optimizer import optimize_energy

app = FastAPI(title="GridWise Optimizer API", version="1.0.0")

# Enable CORS so the HTML/JS Dashboard frontend can communicate with the backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows requests from any frontend origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check():
    return {"status": "ok"}


@app.post("/optimize-energy", response_model=OptimizeResponse)
def optimize_energy_endpoint(req: OptimizeRequest):
    try:
        # Phase 1: Serialize Pydantic objects into dictionaries
        hours_dict = [h.model_dump() for h in req.hours]
        battery_dict = req.battery.model_dump()

        # Phase 2: Interpret natural language operator directives via LLM
        raw_directives = interpret_operator_notes(
            req.operator_notes, 
            req.battery.capacity_kwh
        )

        # Phase 3: Validate and sanitize LLM outputs via deterministic Guardrails
        validated_directives = validate_all_directives(
            raw_directives, 
            len(req.operator_notes), 
            req.battery.capacity_kwh
        )

        # Phase 4: Solve 24-hour linear optimization problem via PuLP
        optimization_result = optimize_energy(
            hours_dict, 
            battery_dict, 
            validated_directives
        )

        # Phase 5: Construct structured response
        return OptimizeResponse(
            scenario_id=req.scenario_id,
            directive_interpretation=validated_directives,
            hourly_plan=optimization_result["hourly_plan"],
            total_grid_kwh=optimization_result["total_grid_kwh"],
            total_cost_bdt=optimization_result["total_cost_bdt"],
            peak_grid_kwh=optimization_result["peak_grid_kwh"],
            plan_summary="Schedule successfully optimized considering directive constraints and battery limits."
        )

    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except RuntimeError as re:
        raise HTTPException(status_code=400, detail=str(re))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")