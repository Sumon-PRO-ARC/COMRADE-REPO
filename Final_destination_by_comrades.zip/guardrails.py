import math


ALLOWED_DIRECTIVES = {
    "solar_reduction",
    "minimum_battery_reserve",
    "no_charge_window",
    "no_discharge_window",
    "max_grid_window",
    "no_op",
}


def valid_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def normalize_hours(hours):
    if not isinstance(hours, list):
        return None

    cleaned = []
    for h in hours:
        if isinstance(h, int) and not isinstance(h, bool) and 0 <= h <= 23:
            cleaned.append(h)
        else:
            return None

    if not cleaned:
        return None

    return sorted(list(set(cleaned)))


def no_op(note_index, reason="Invalid or irrelevant directive"):
    return {
        "note_index": note_index,
        "applies": False,
        "directive_type": "no_op",
        "structured_adjustment": None,
        "explanation": reason
    }


def validate_directive(raw, note_index, battery_capacity):
    if not isinstance(raw, dict):
        return no_op(note_index, "Malformed LLM output.")

    directive_type = raw.get("directive_type")
    applies = raw.get("applies")
    adjustment = raw.get("structured_adjustment")
    explanation = raw.get("explanation", "")

    if directive_type not in ALLOWED_DIRECTIVES:
        return no_op(note_index, "Unsupported directive type.")

    if directive_type == "no_op":
        return {
            "note_index": note_index,
            "applies": False,
            "directive_type": "no_op",
            "structured_adjustment": None,
            "explanation": str(explanation)
        }

    if applies is not True:
        return no_op(note_index, "Non-no_op directive must have applies=true.")

    if not isinstance(adjustment, dict):
        return no_op(note_index, "Missing structured adjustment.")

    raw_hours = adjustment.get("hours")
    hours = normalize_hours(raw_hours)

    if hours is None:
        return no_op(note_index, "Hours must contain valid integers between 0 and 23.")

    if directive_type == "solar_reduction":
        factor = adjustment.get("factor")
        if not valid_number(factor) or factor < 0 or factor > 1:
            return no_op(note_index, "Solar factor must be between 0 and 1.")

        return {
            "note_index": note_index,
            "applies": True,
            "directive_type": directive_type,
            "structured_adjustment": {
                "hours": hours,
                "factor": float(factor)
            },
            "explanation": str(explanation)
        }

    if directive_type == "minimum_battery_reserve":
        minimum_energy = adjustment.get("minimum_energy_kwh")
        if not valid_number(minimum_energy) or minimum_energy < 0 or minimum_energy > battery_capacity:
            return no_op(note_index, "Battery reserve is outside valid range.")

        return {
            "note_index": note_index,
            "applies": True,
            "directive_type": directive_type,
            "structured_adjustment": {
                "hours": hours,
                "minimum_energy_kwh": float(minimum_energy)
            },
            "explanation": str(explanation)
        }

    if directive_type == "no_charge_window":
        return {
            "note_index": note_index,
            "applies": True,
            "directive_type": directive_type,
            "structured_adjustment": {"hours": hours},
            "explanation": str(explanation)
        }

    if directive_type == "no_discharge_window":
        return {
            "note_index": note_index,
            "applies": True,
            "directive_type": directive_type,
            "structured_adjustment": {"hours": hours},
            "explanation": str(explanation)
        }

    if directive_type == "max_grid_window":
        max_grid = adjustment.get("max_grid_kwh")
        if not valid_number(max_grid) or max_grid < 0:
            return no_op(note_index, "Grid cap must be non-negative.")

        return {
            "note_index": note_index,
            "applies": True,
            "directive_type": directive_type,
            "structured_adjustment": {
                "hours": hours,
                "max_grid_kwh": float(max_grid)
            },
            "explanation": str(explanation)
        }

    return no_op(note_index, "Safe fallback.")


def validate_all_directives(raw_directives, note_count, battery_capacity):
    if not isinstance(raw_directives, list):
        raw_directives = []

    result = []
    for i in range(note_count):
        candidate = None
        for item in raw_directives:
            if isinstance(item, dict) and item.get("note_index") == i:
                candidate = item
                break

        if candidate is None:
            result.append(no_op(i, "No valid interpretation returned for this note."))
        else:
            result.append(validate_directive(candidate, i, battery_capacity))

    return result