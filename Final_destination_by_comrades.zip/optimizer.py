import pulp


def optimize_energy(hours, battery, directives):
    n = len(hours)
    if n != 24:
        raise ValueError("Exactly 24 hourly entries are required.")

    capacity = float(battery["capacity_kwh"])
    initial_energy = float(battery["initial_energy_kwh"])
    base_minimum = float(battery["minimum_energy_kwh"])
    max_charge = float(battery["max_charge_kwh_per_hour"])
    max_discharge = float(battery["max_discharge_kwh_per_hour"])

    solar_factor = [1.0] * 24
    reserve_limit = [base_minimum] * 24
    no_charge = [False] * 24
    no_discharge = [False] * 24
    grid_limit = [None] * 24

    for directive in directives:
        if not directive.get("applies", False):
            continue

        dtype = directive.get("directive_type")
        adj = directive.get("structured_adjustment") or {}
        affected_hours = adj.get("hours", [])

        if dtype == "solar_reduction":
            factor = float(adj["factor"])
            for h in affected_hours:
                solar_factor[h] *= factor

        elif dtype == "minimum_battery_reserve":
            minimum = float(adj["minimum_energy_kwh"])
            for h in affected_hours:
                reserve_limit[h] = max(reserve_limit[h], minimum)

        elif dtype == "no_charge_window":
            for h in affected_hours:
                no_charge[h] = True

        elif dtype == "no_discharge_window":
            for h in affected_hours:
                no_discharge[h] = True

        elif dtype == "max_grid_window":
            maximum = float(adj["max_grid_kwh"])
            for h in affected_hours:
                if grid_limit[h] is None:
                    grid_limit[h] = maximum
                else:
                    grid_limit[h] = min(grid_limit[h], maximum)

    effective_solar = [float(hours[h]["solar_kwh"]) * solar_factor[h] for h in range(24)]

    model = pulp.LpProblem("GridWise_Optimization", pulp.LpMinimize)

    grid = {h: pulp.LpVariable(f"grid_{h}", lowBound=0) for h in range(24)}
    solar_used = {h: pulp.LpVariable(f"solar_used_{h}", lowBound=0) for h in range(24)}
    charge = {h: pulp.LpVariable(f"charge_{h}", lowBound=0) for h in range(24)}
    discharge = {h: pulp.LpVariable(f"discharge_{h}", lowBound=0) for h in range(24)}
    battery_energy = {h: pulp.LpVariable(f"battery_energy_{h}", lowBound=0, upBound=capacity) for h in range(24)}

    model += pulp.lpSum(grid[h] * float(hours[h]["tariff_bdt_per_kwh"]) for h in range(24))

    for h in range(24):
        demand = float(hours[h]["demand_kwh"])

        model += (solar_used[h] <= effective_solar[h])
        model += (charge[h] <= max_charge)
        model += (discharge[h] <= max_discharge)

        if h == 0:
            model += (battery_energy[h] == initial_energy + charge[h] - discharge[h])
        else:
            model += (battery_energy[h] == battery_energy[h - 1] + charge[h] - discharge[h])

        model += (battery_energy[h] >= reserve_limit[h])
        model += (grid[h] + solar_used[h] + discharge[h] == demand + charge[h])

        if no_charge[h]:
            model += (charge[h] == 0)
        if no_discharge[h]:
            model += (discharge[h] == 0)
        if grid_limit[h] is not None:
            model += (grid[h] <= grid_limit[h])

    model += (battery_energy[23] == initial_energy)

    status = model.solve(pulp.PULP_CBC_CMD(msg=False))

    if pulp.LpStatus[status] != "Optimal":
        raise RuntimeError(f"Optimization failed: {pulp.LpStatus[status]}")

    hourly_plan = []
    for h in range(24):
        g_val = max(0.0, float(pulp.value(grid[h]) or 0.0))
        s_val = max(0.0, float(pulp.value(solar_used[h]) or 0.0))
        c_val = max(0.0, float(pulp.value(charge[h]) or 0.0))
        d_val = max(0.0, float(pulp.value(discharge[h]) or 0.0))
        e_val = max(0.0, float(pulp.value(battery_energy[h]) or 0.0))

        if c_val > 1e-5:
            action = "charge"
            b_val = c_val
        elif d_val > 1e-5:
            action = "discharge"
            b_val = d_val
        else:
            action = "idle"
            b_val = 0.0

        hourly_plan.append({
            "hour": h,
            "grid_kwh": round(g_val, 4),
            "solar_used_kwh": round(s_val, 4),
            "battery_action": action,
            "battery_kwh": round(b_val, 4),
            "battery_energy_after_kwh": round(e_val, 4)
        })

    total_grid = sum(item["grid_kwh"] for item in hourly_plan)
    total_cost = sum(item["grid_kwh"] * float(hours[item["hour"]]["tariff_bdt_per_kwh"]) for item in hourly_plan)
    peak_grid = max(item["grid_kwh"] for item in hourly_plan)

    return {
        "hourly_plan": hourly_plan,
        "total_grid_kwh": round(total_grid, 4),
        "total_cost_bdt": round(total_cost, 4),
        "peak_grid_kwh": round(peak_grid, 4)
    }