import math
from typing import List, Optional, Literal
from pydantic import BaseModel, Field, field_validator


class HourData(BaseModel):
    hour: int = Field(ge=0, le=23, description="Hour index from 0 to 23")
    demand_kwh: float = Field(ge=0, description="Energy demand in kWh")
    solar_kwh: float = Field(ge=0, description="Forecasted solar generation in kWh")
    tariff_bdt_per_kwh: float = Field(ge=0, description="Grid tariff rate in BDT/kWh")

    @field_validator("demand_kwh", "solar_kwh", "tariff_bdt_per_kwh")
    def check_finite(cls, v):
        if not math.isfinite(v):
            raise ValueError("Values must be finite numbers.")
        return v


class BatterySpec(BaseModel):
    capacity_kwh: float = Field(gt=0, description="Total usable storage capacity in kWh")
    initial_energy_kwh: float = Field(ge=0, description="Energy in battery at start of day (hour 0)")
    minimum_energy_kwh: float = Field(ge=0, description="Default safety floor reserve in kWh")
    max_charge_kwh_per_hour: float = Field(ge=0, description="Maximum charge speed per hour")
    max_discharge_kwh_per_hour: float = Field(ge=0, description="Maximum discharge speed per hour")

    @field_validator("*")
    def check_finite(cls, v):
        if isinstance(v, (float, int)) and not math.isfinite(v):
            raise ValueError("Battery specification values must be finite numbers.")
        return v


class OptimizeRequest(BaseModel):
    scenario_id: str = Field(description="Unique scenario identifier")
    operator_notes: List[str] = Field(default_factory=list, description="Unstructured natural language operator directives")
    hours: List[HourData] = Field(min_length=24, max_length=24, description="Hourly profiles for 24 hours")
    battery: BatterySpec


class StructuredAdjustment(BaseModel):
    hours: List[int] = Field(
        description="List of target hour indices (0-23) affected by the directive."
    )
    factor: Optional[float] = Field(
        default=None, 
        ge=0.0, 
        le=1.0, 
        description="Fraction of remaining usable solar capacity."
    )
    minimum_energy_kwh: Optional[float] = Field(
        default=None, 
        ge=0.0, 
        description="Updated minimum energy reserve target for battery in kWh."
    )
    max_grid_kwh: Optional[float] = Field(
        default=None, 
        ge=0.0, 
        description="Power import ceiling from the grid in kWh per hour."
    )

    @field_validator("hours")
    def check_hours(cls, v):
        if any(h < 0 or h > 23 for h in v):
            raise ValueError("Hours must be between 0 and 23.")
        return sorted(list(set(v)))


class DirectiveInterpretation(BaseModel):
    note_index: int = Field(description="0-indexed position corresponding to operator_notes input")
    applies: bool = Field(description="False if directive is irrelevant/distractor (no_op), True otherwise")
    directive_type: Literal[
        "solar_reduction",
        "minimum_battery_reserve",
        "no_charge_window",
        "no_discharge_window",
        "max_grid_window",
        "no_op"
    ]
    structured_adjustment: Optional[StructuredAdjustment] = Field(
        default=None, 
        description="Contains specific numerical/time constraints."
    )
    explanation: str = Field(description="Brief reason for the classification")


class DirectiveBatchResponse(BaseModel):
    interpretations: List[DirectiveInterpretation]


class HourlyPlanOutput(BaseModel):
    hour: int = Field(ge=0, le=23)
    grid_kwh: float = Field(ge=0, description="Grid import energy in kWh")
    solar_used_kwh: float = Field(ge=0, description="Solar energy utilized in kWh")
    battery_action: Literal["charge", "discharge", "idle"] = Field(description="Primary battery mode")
    battery_kwh: float = Field(ge=0, description="Energy charged or discharged during this hour")
    battery_energy_after_kwh: float = Field(ge=0, description="State of Charge at end of hour")


class OptimizeResponse(BaseModel):
    scenario_id: str
    directive_interpretation: List[DirectiveInterpretation]
    hourly_plan: List[HourlyPlanOutput]
    total_grid_kwh: float = Field(ge=0)
    total_cost_bdt: float = Field(ge=0)
    peak_grid_kwh: float = Field(ge=0)
    plan_summary: str